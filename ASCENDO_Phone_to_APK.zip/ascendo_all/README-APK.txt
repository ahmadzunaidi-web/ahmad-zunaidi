ASCENDO — Android/APK preparation

CURRENT PROJECT
This folder is an offline-friendly web app prototype. It includes:
- 24 sets
- original page images in assets/
- digital answer fields
- autosave in localStorage
- backup/restore progress
- PWA manifest + service worker

IMPORTANT
The final "completed PDF with answers over the original pages" is a separate PDF-engine step.
This project currently does not claim that feature is complete.

NEXT STEP TO MAKE APK
Recommended: use Android Studio + WebView or a trusted WebView-to-APK wrapper.
1. Open Android Studio.
2. Create an Empty Activity project.
3. Put this `ascendo_all` folder under the app's local assets, e.g.:
   app/src/main/assets/ascendo/
4. Use a WebView and load:
   file:///android_asset/ascendo/index.html
5. Enable JavaScript and DOM storage.
6. Build > Generate App Bundle(s) / APK(s) > Generate APK(s).

For the final app, use Android's PdfDocument/PdfRenderer or a PDF library to overlay answers on the original pages.
